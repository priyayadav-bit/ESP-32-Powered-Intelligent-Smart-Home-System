# ESP32 Powered Intelligent Smart Home System

A smart lighting system built with an **ESP32**, an **LDR light sensor** and a **relay module**.

- The light turns **ON automatically in the dark** and **OFF when there is enough light**.
- Lights can be switched with **push buttons** (works without internet).
- Lights can be controlled from a **smartphone app** and with **Google Assistant voice commands** using [Sinric Pro](https://sinric.pro/).

## Quick start

1. **Wire the hardware.** ESP32, LDR, relay module and push buttons. The pins are listed at the top of [`firmware/smart_home/smart_home.ino`](firmware/smart_home/smart_home.ino).
2. **Install** Arduino IDE, the **ESP32 board package** (Espressif) and the **SinricPro** library.
3. **Add your keys.** In `firmware/smart_home/`, copy `secrets.h.example` to `secrets.h` and fill in your Wi-Fi and Sinric Pro details.
   `secrets.h` is in `.gitignore`, so it is never uploaded.
4. **Upload** the sketch (board: *ESP32 Dev Module*) and open the Serial Monitor at **115200**.
5. **Create devices in Sinric Pro** (one *Switch* per light) and link the service in the **Google Home** app.

## How the three modes work

| Mode | How | Needs internet? |
|------|-----|-----------------|
| Automatic | LDR measures room light and switches light 1 | No |
| Manual | Push button toggles a light | No |
| Remote / voice | App or Google Assistant through Sinric Pro | Yes |

The **last command wins**: a button or app command stays until the room light changes from dark to bright or the other way round.

## Documentation

| File | What is inside |
|------|----------------|
| [`plan.md`](plan.md) | Project plan: scope, architecture, pin plan, build order, tests and risks |
| [`report.md`](report.md) | Full project report |
| [`firmware/`](firmware) | ESP32 code and the secrets template |

## Safety

The lights use **mains voltage**, which is dangerous. Switch off the supply before touching wiring, keep mains wires inside an insulated enclosure, and test with a low-voltage load (like an LED) first.

## License

Add a license file (for example MIT) before sharing publicly.
